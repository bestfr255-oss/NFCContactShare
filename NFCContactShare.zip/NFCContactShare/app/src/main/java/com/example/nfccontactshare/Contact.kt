package com.example.nfccontactshare

data class Contact(val name: String, val phone: String)
